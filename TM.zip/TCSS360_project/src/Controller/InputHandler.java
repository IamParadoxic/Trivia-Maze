package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import View.TriviaMazeMain;
import View.GUI;

public class InputHandler implements ActionListener{
	
	private TriviaMazeMain myTmm;
	private String myText;
	
	public InputHandler(TriviaMazeMain tmm) {
		
		this.myTmm = tmm;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		myText = myTmm.gui.getJTF().getText();
		myTmm.gui.getJTF().setText("");
	}
}
